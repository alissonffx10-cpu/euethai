"""
validators.py
Funções de validação de entrada do usuário.
"""

import re


def validate_email(email: str) -> str | None:
    """Retorna mensagem de erro ou None se válido."""
    if not email.strip():
        return "O e-mail não pode estar vazio."
    pattern = r"^[^@\s]+@[^@\s]+\.[^@\s]+$"
    if not re.match(pattern, email.strip()):
        return "Formato de e-mail inválido."
    return None


def validate_password(password: str) -> str | None:
    """Retorna mensagem de erro ou None se válido."""
    if len(password) < 6:
        return "A senha deve ter ao menos 6 caracteres."
    return None


def validate_display_name(name: str) -> str | None:
    """Retorna mensagem de erro ou None se válido."""
    if not name.strip():
        return "O nome não pode estar vazio."
    if len(name.strip()) < 2:
        return "O nome deve ter ao menos 2 caracteres."
    return None
