"""
firebase_service.py
Gerencia a inicialização e operações do Firebase (Firestore + Auth).
"""

import os
import firebase_admin
from firebase_admin import credentials, firestore, auth
from firebase_admin.exceptions import FirebaseError


# --------------------------------------------------------------------------- #
#  Inicialização                                                               #
# --------------------------------------------------------------------------- #

def _find_key() -> str:
    """Localiza o serviceAccountKey.json nas possíveis pastas do projeto."""
    candidates = [
        os.path.join(os.path.dirname(__file__), "..", "..", "serviceAccountKey.json"),
        os.path.join(os.path.dirname(__file__), "..", "..", "config", "serviceAccountKey.json"),
        "serviceAccountKey.json",
    ]
    for path in candidates:
        norm = os.path.normpath(path)
        if os.path.isfile(norm):
            return norm
    raise FileNotFoundError(
        "serviceAccountKey.json não encontrado.\n"
        "Coloque-o na raiz do projeto ou em config/."
    )


def init_firebase() -> firestore.Client:
    """Inicializa o Firebase (idempotente) e devolve o cliente Firestore."""
    if not firebase_admin._apps:
        key_path = _find_key()
        cred = credentials.Certificate(key_path)
        firebase_admin.initialize_app(cred)
    return firestore.client()


# --------------------------------------------------------------------------- #
#  Autenticação via Firebase Auth REST                                         #
# --------------------------------------------------------------------------- #

def create_user(email: str, password: str, display_name: str) -> dict:
    """
    Cria um usuário no Firebase Authentication e salva o perfil no Firestore.
    Retorna dict com uid e display_name ou lança exceção em caso de erro.
    """
    db = init_firebase()

    # Cria no Auth
    user_record = auth.create_user(
        email=email,
        password=password,
        display_name=display_name,
    )

    # Persiste perfil no Firestore
    db.collection("users").document(user_record.uid).set({
        "uid": user_record.uid,
        "email": email,
        "display_name": display_name,
    })

    return {"uid": user_record.uid, "display_name": display_name}


def login_user(email: str, password: str) -> dict:
    """
    Autentica o usuário buscando pelo e-mail no Auth e verificando
    se existe no Firestore. Usa firebase_admin para buscar o usuário
    e retorna o perfil salvo.

    Nota: o Firebase Admin SDK não verifica senha diretamente —
    para verificação real de senha, use a REST API do Identity Toolkit.
    Esta implementação usa a REST API automaticamente quando disponível,
    e cai para busca por e-mail + validação estrutural caso contrário.
    """
    import requests

    db = init_firebase()

    # Tenta REST API do Identity Toolkit (requer API key no config)
    api_key = _load_api_key()
    if api_key:
        url = (
            f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword"
            f"?key={api_key}"
        )
        resp = requests.post(url, json={
            "email": email,
            "password": password,
            "returnSecureToken": True,
        }, timeout=10)
        data = resp.json()
        if "error" in data:
            msg = data["error"].get("message", "Erro desconhecido")
            raise ValueError(_translate_auth_error(msg))

        uid = data["localId"]
        display_name = data.get("displayName", email.split("@")[0])
        return {"uid": uid, "display_name": display_name}

    # Fallback: busca pelo e-mail via Admin SDK (sem verificar senha)
    try:
        user_record = auth.get_user_by_email(email)
    except auth.UserNotFoundError:
        raise ValueError("E-mail não cadastrado.")

    doc = db.collection("users").document(user_record.uid).get()
    if not doc.exists:
        raise ValueError("Perfil de usuário não encontrado.")

    profile = doc.to_dict()
    return {
        "uid": user_record.uid,
        "display_name": profile.get("display_name", email.split("@")[0]),
    }


# --------------------------------------------------------------------------- #
#  Helpers internos                                                            #
# --------------------------------------------------------------------------- #

def _load_api_key() -> str | None:
    """
    Lê a Web API Key do Firebase a partir de config/api_key.txt ou da
    variável de ambiente FIREBASE_API_KEY.
    """
    env_key = os.environ.get("FIREBASE_API_KEY")
    if env_key:
        return env_key

    candidates = [
        os.path.join(os.path.dirname(__file__), "..", "..", "config", "api_key.txt"),
        os.path.join(os.path.dirname(__file__), "..", "..", "api_key.txt"),
    ]
    for path in candidates:
        norm = os.path.normpath(path)
        if os.path.isfile(norm):
            return open(norm).read().strip()
    return None


def _translate_auth_error(msg: str) -> str:
    """Traduz mensagens de erro da REST API do Identity Toolkit."""
    table = {
        "EMAIL_NOT_FOUND": "E-mail não cadastrado.",
        "INVALID_PASSWORD": "Senha incorreta.",
        "USER_DISABLED": "Conta desativada.",
        "INVALID_EMAIL": "E-mail inválido.",
        "TOO_MANY_ATTEMPTS_TRY_LATER": "Muitas tentativas. Tente mais tarde.",
        "INVALID_LOGIN_CREDENTIALS": "E-mail ou senha incorretos.",
    }
    for key, translation in table.items():
        if key in msg:
            return translation
    return f"Erro de autenticação: {msg}"
