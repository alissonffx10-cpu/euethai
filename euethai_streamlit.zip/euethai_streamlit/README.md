# euethai — Streamlit

Sistema de login e cadastro em Python com Streamlit + Firebase.

## Como rodar

```bash
pip install -r requirements.txt
streamlit run app.py
```

Abre automaticamente no navegador em `http://localhost:8501`

## Estrutura

```
euethai_streamlit/
├── app.py                  # Aplicativo principal
├── requirements.txt
├── config/
│   ├── serviceAccountKey.json  # 🔒 não versionar
│   └── api_key.txt             # 🔒 não versionar
└── src/
    ├── firebase_service.py
    └── validators.py
```
