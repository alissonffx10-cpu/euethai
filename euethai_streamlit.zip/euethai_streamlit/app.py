"""
app.py
Aplicativo euethai — Login e Cadastro com Streamlit + Firebase.
"""

import streamlit as st
from src.firebase_service import create_user, login_user
from src.validators import validate_email, validate_password, validate_display_name

# ─────────────────────────────────────────────────────────────────────────── #
#  Configuração da página                                                      #
# ─────────────────────────────────────────────────────────────────────────── #

st.set_page_config(
    page_title="euethai",
    page_icon="✦",
    layout="centered",
)

# ─────────────────────────────────────────────────────────────────────────── #
#  Estilos globais                                                             #
# ─────────────────────────────────────────────────────────────────────────── #

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Inter:wght@300;400;500;600&display=swap');

/* Reset e fundo */
html, body, [data-testid="stAppViewContainer"], [data-testid="stApp"] {
    background-color: #0D0D0D !important;
    color: #F0F0F0 !important;
    font-family: 'Inter', sans-serif !important;
}

[data-testid="stHeader"] { background: transparent !important; }
[data-testid="stToolbar"] { display: none; }
#MainMenu { visibility: hidden; }
footer { visibility: hidden; }

/* Bloco central */
[data-testid="stVerticalBlock"] { gap: 0.4rem; }

/* Inputs */
input[type="text"], input[type="password"], input[type="email"] {
    background-color: #1E1E1E !important;
    color: #F0F0F0 !important;
    border: 1px solid #2A2A2A !important;
    border-radius: 10px !important;
    font-family: 'Inter', sans-serif !important;
    font-size: 14px !important;
}
input:focus {
    border-color: #00C9A7 !important;
    box-shadow: 0 0 0 2px rgba(0,201,167,0.15) !important;
}

/* Labels dos inputs */
label[data-testid="stWidgetLabel"] p {
    color: #888 !important;
    font-size: 12px !important;
    font-weight: 500 !important;
    text-transform: uppercase !important;
    letter-spacing: 0.05em !important;
}

/* Botão primário */
[data-testid="stButton"] > button {
    background-color: #00C9A7 !important;
    color: #0D0D0D !important;
    border: none !important;
    border-radius: 10px !important;
    font-family: 'Inter', sans-serif !important;
    font-weight: 600 !important;
    font-size: 14px !important;
    height: 44px !important;
    width: 100% !important;
    transition: background 0.2s !important;
}
[data-testid="stButton"] > button:hover {
    background-color: #00B096 !important;
}

/* Divisor */
hr { border-color: #2A2A2A !important; margin: 1.5rem 0 !important; }

/* Tabs */
[data-testid="stTabs"] [data-baseweb="tab-list"] {
    background: #161616 !important;
    border-radius: 10px !important;
    padding: 4px !important;
    gap: 4px !important;
    border: 1px solid #2A2A2A !important;
}
[data-testid="stTabs"] [data-baseweb="tab"] {
    background: transparent !important;
    color: #888 !important;
    border-radius: 8px !important;
    font-family: 'Inter', sans-serif !important;
    font-weight: 500 !important;
    font-size: 13px !important;
    border: none !important;
}
[data-testid="stTabs"] [aria-selected="true"] {
    background: #00C9A7 !important;
    color: #0D0D0D !important;
}
[data-testid="stTabPanel"] {
    background: #161616 !important;
    border-radius: 12px !important;
    padding: 1.5rem !important;
    border: 1px solid #2A2A2A !important;
    margin-top: 8px !important;
}
</style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────── #
#  Session state                                                               #
# ─────────────────────────────────────────────────────────────────────────── #

if "user" not in st.session_state:
    st.session_state.user = None

# ─────────────────────────────────────────────────────────────────────────── #
#  Telas                                                                       #
# ─────────────────────────────────────────────────────────────────────────── #

def show_auth():
    """Tela de Login / Cadastro."""

    # Logo
    st.markdown("""
    <div style='text-align:center; padding: 2.5rem 0 1.5rem;'>
        <span style='font-family: Space Mono, monospace; font-size: 2rem;
                     font-weight: 700; color: #00C9A7; letter-spacing: -1px;'>
            euethai
        </span>
        <p style='color: #555; font-size: 13px; margin-top: 6px;'>
            sistema de autenticação
        </p>
    </div>
    """, unsafe_allow_html=True)

    tab_login, tab_register = st.tabs(["Entrar", "Cadastrar"])

    # ── Login ────────────────────────────────────────────────────────────── #
    with tab_login:
        email    = st.text_input("E-mail", placeholder="seu@email.com", key="l_email")
        password = st.text_input("Senha",  placeholder="••••••••", type="password", key="l_pass")

        if st.button("Entrar", key="btn_login"):
            err = validate_email(email) or validate_password(password)
            if err:
                st.error(err)
            else:
                with st.spinner("Autenticando…"):
                    try:
                        user = login_user(email, password)
                        st.session_state.user = user
                        st.rerun()
                    except Exception as e:
                        st.error(str(e))

    # ── Cadastro ─────────────────────────────────────────────────────────── #
    with tab_register:
        name  = st.text_input("Nome",             placeholder="Seu nome completo",  key="r_name")
        email = st.text_input("E-mail",           placeholder="seu@email.com",      key="r_email")
        pw    = st.text_input("Senha",            placeholder="••••••••", type="password", key="r_pass")
        pw2   = st.text_input("Confirmar senha",  placeholder="••••••••", type="password", key="r_pass2")

        if st.button("Criar conta", key="btn_register"):
            err = (
                validate_display_name(name)
                or validate_email(email)
                or validate_password(pw)
            )
            if err:
                st.error(err)
            elif pw != pw2:
                st.error("As senhas não coincidem.")
            else:
                with st.spinner("Criando conta…"):
                    try:
                        create_user(email, pw, name)
                        st.success(f"Conta criada! Bem-vindo, {name}. Faça login para continuar.")
                    except Exception as e:
                        st.error(str(e))


def show_dashboard():
    """Tela principal pós-login."""
    user = st.session_state.user
    name = user.get("display_name", "Usuário")
    uid  = (user.get("uid") or "")[:16] + "…"

    # Topbar
    col1, col2 = st.columns([5, 1])
    with col1:
        st.markdown(f"""
        <span style='font-family: Space Mono, monospace; font-size: 1.3rem;
                     font-weight: 700; color: #00C9A7;'>euethai</span>
        """, unsafe_allow_html=True)
    with col2:
        if st.button("Sair", key="btn_logout"):
            st.session_state.user = None
            st.rerun()

    st.markdown("<hr>", unsafe_allow_html=True)

    # Saudação
    st.markdown(f"""
    <h2 style='color: #F0F0F0; font-family: Inter, sans-serif;
               font-weight: 600; margin-bottom: 4px;'>
        Olá, {name} 👋
    </h2>
    <p style='color: #888; font-size: 14px; margin-top: 0;'>
        Você está autenticado com sucesso.
    </p>
    """, unsafe_allow_html=True)

    # Card de sessão
    st.markdown(f"""
    <div style='background: #161616; border: 1px solid #2A2A2A;
                border-radius: 12px; padding: 16px 20px;
                display: flex; align-items: center; gap: 12px; margin-top: 1rem;'>
        <div style='width: 10px; height: 10px; border-radius: 50%;
                    background: #00C9A7; flex-shrink: 0;'></div>
        <span style='color: #F0F0F0; font-size: 14px; flex: 1;'>Sessão ativa</span>
        <span style='color: #444; font-size: 12px; font-family: monospace;'>UID: {uid}</span>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("<hr>", unsafe_allow_html=True)

    # ── Área para novas funcionalidades ──────────────────────────────────── #
    st.markdown("""
    <p style='color: #444; font-size: 13px;'>
        Seu painel estará disponível em breve.
    </p>
    """, unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────── #
#  Roteamento                                                                  #
# ─────────────────────────────────────────────────────────────────────────── #

if st.session_state.user:
    show_dashboard()
else:
    show_auth()
